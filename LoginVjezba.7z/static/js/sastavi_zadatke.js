function addMoreInputPairs() {
    // Clone the template input-container element
    var templateInputContainer = document.querySelector('.input-container');
    var newInputContainer = templateInputContainer.cloneNode(true);

    // Clear the values of the cloned input container
    newInputContainer.querySelectorAll('select').forEach(function (select) {
        select.selectedIndex = 0;
    });

    // Append the cloned input container to the container
    var container = document.querySelector('.input-pairs');
    container.appendChild(newInputContainer);
}
