function validateForm(event) {
    var username = document.getElementById('username').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    var repeatPassword = document.getElementById('repeatPassword').value;
    // Matching passwords
    if (password !== repeatPassword) {
        alert('Passwords do not match.');
        return false;
    }


    console.log('Proslo')
    return true;
}
