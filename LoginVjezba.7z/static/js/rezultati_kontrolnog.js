var submit_button = document.getElementById('submit_button');
submit_button.style.display = 'block';