import secrets
from datetime import datetime,timedelta
from pymongo.mongo_client import MongoClient
import bcrypt
uri = "mongodb+srv://aleksandra:aleksandra@schooldb.x1gsd5j.mongodb.net/?retryWrites=true&w=majority"

mongo = MongoClient(uri)

class User:
    def __init__(self, username, email, password):
        self.username = username
        self.email = email
        self.password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        self.token_data = generate_token()
        new_user = {'email': self.email, 'username': self.username, 'password': self.password, 'verified': False,
                    'token_data': self.token_data}
        mongo.schoolDB.profesori.insert_one(new_user)



def is_username_email_taken(username,email):
    username_t = mongo.schoolDB.profesori.find_one({'username': username})
    email_t = mongo.schoolDB.profesori.find_one({'email': email})
    result = {}
    result["username_taken"] = username_t is not None
    result["email_taken"] = email_t is not None
    result["username_taken_verified"] = result["username_taken"] and username_t['verified']
    result["email_taken_verified"] = result["email_taken"] and email_t['verified']
    return result



def delete_user_by_email(email):
    mongo.schoolDB.profesori.delete_one({'email': email, 'verified': False})

def user_authentication(username,password):
    result = {}
    user = mongo.schoolDB.profesori.find_one({'username': username})
    result['user_exist'] = user is not None
    result['user_verified'] = result['user_exist'] and user['verified']
    result['user_authentication'] = result['user_exist'] and result['user_verified'] and bcrypt.checkpw(password.encode('utf-8'), user['password'])
    return result

def token_verification(token):
    user = mongo.schoolDB.profesori.find_one({'token_data.token': token, 'verified': False})
    token_timestamp = user['token_data']['timestamp']
    expiration_time = token_timestamp + timedelta(hours=24)
    if datetime.utcnow() > expiration_time:
        # Token has expired, delete the user
        mongo.schoolDB.profesori.delete_one({'_id': user['_id']})
        return False
    else:
        # Mark the token as used
        mongo.schoolDB.profesori.update_one({'_id': user['_id']}, {'$set': {'verified': True}})
        return True

def generate_token():
    token = secrets.token_urlsafe(16)  # Adjust the length of the token as needed
    timestamp = datetime.utcnow()  # type: ignore
    return {'token': token, 'timestamp': timestamp}


def delete_expired_unverified_users():
    expiration_time = datetime.utcnow() - timedelta(minutes=30)  # type: ignore
    mongo.schoolDB.profesori.delete_many({'verified': False, 'token_data.timestamp': {'$lt': expiration_time}})

