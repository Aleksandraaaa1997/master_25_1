from flask import Flask, render_template, request, redirect, url_for, session
from flask_mail import Mail, Message
from user import User, is_username_email_taken, token_verification,delete_user_by_email,user_authentication, mongo
from email.mime.text import MIMEText
from datetime import datetime
import random

app = Flask(__name__)
app.secret_key = "your_secret_key"
# Initialize Flask-Mail
app.config['MAIL_SERVER'] = 'smtp.gmail.com'  # Replace with your SMTP server
app.config['MAIL_PORT'] = 587  # Replace with your SMTP server port
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False
app.config['MAIL_USERNAME'] = 'enabizpcr@gmail.com'  # Replace with your email
app.config['MAIL_PASSWORD'] = 'kdirxgaptkmhfvim'  # Replace with your email password

mail = Mail(app)

@app.route('/home')
@app.route('/')
def home():
    return render_template('home.html')


@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        email = request.form.get("email")
        username = request.form.get("username")
        password = request.form.get("password")
        result = is_username_email_taken(username,email)
        if result["username_taken_verified"] or result["email_taken_verified"]:
            return render_template('register.html', username_taken=result["username_taken_verified"],
                                   email_taken=result["email_taken_verified"], token_problems = False)

        if result["username_taken"]:
            return render_template('register.html', username_taken=True, email_taken=False, token_problems = False)

        if result["email_taken"]:
            delete_user_by_email(email)

        print('1')
        print('3')
        usr = User(username,email,password)

        msg = Message("Verification Email", sender='noreply@demo.com', recipients=[email])
        msg.body = f'Click the following link to verify your account for user {username}: http://127.0.0.1:5000/verify/{usr.token_data["token"]}'

        try:
            mail.send(msg)
            print('Poslata poruka')
            return render_template('registration_successful.html',text='Uspesna registracija. Potvrdite svoju email adresu ulaskom na link koji vam je poslat na nju')

        except Exception as e:
            print(f"Error sending email: {e}")
            return render_template('registration_failed.html',text = 'Neuspesna registracija molim vas proverite da li je uneti mail odgovarajuci.')

    elif request.method == 'GET':
        print('4')
        return render_template('register.html',username_taken = False, email_taken=False, token_problems = False)


@app.route('/login_prof', methods=['POST','GET'])
def login_prof():
    input_data = {}
    if request.method == 'GET':
        return render_template('login_prof.html',input_data = input_data)
    elif request.method == 'POST':
        username = request.form.get("username")
        password = request.form.get("password")
        result = user_authentication(username,password)

        if result['user_authentication']:
            session['username'] = username
            return redirect(url_for('kontrolni_rezultati_izbor'))

        if not result['user_exist']:
            input_data['username_exist'] = True
            return render_template('login_prof.html',input_data = input_data)

        if not result['user_verified']:
            input_data['user_not_verified'] = True
            return render_template('login_prof.html',input_data = input_data)

        if not result['user_authentication']:
            input_data['user_wrong_pass'] = True
            return render_template('login_prof.html',input_data = input_data)



@app.route('/verify/<token>')
def verify_token(token):
    try:
        result = token_verification(token)

        if result:
            input_data = {}
            input_data['verified_token'] = True
            return render_template('login_prof.html', input_data=input_data)
    except:
        return render_template('register.html', username_taken=False, email_taken=False, token_problems=True)

@app.route('/sastavi_zadatke', methods=['POST', 'GET'])
def sastavi_zadatke():
    if request.method == 'GET':
        oblasti = ['Jednačine', 'Prava', 'Nejednačine', 'Test']
        tezina = ['Lakši', 'Srednji', 'Teški']
        kolicina = [i for i in range(1, 11)]
        return render_template('sastavi_zadatke.html', oblasti=oblasti, tezina=tezina, kolicina=kolicina)
    if request.method == 'POST':
        ime_kontrolnog = request.form.get('imeKontrolnog')
        start_date = request.form.get('startDate')
        end_date = request.form.get('endDate')
        potrebno_vreme = request.form.get('vremeZaRad')
        oblasti = request.form.getlist('oblast_name')
        tezine = request.form.getlist('tezinas_name')
        kolicine = request.form.getlist('kolicina_name')
        data = {
            'ime_kontrolnog': ime_kontrolnog,
            'start_date': start_date,
            'end_date': end_date,
            'oblasti': oblasti,
            'tezine': tezine,
            'kolicina': kolicine,
            'potrebno_vreme': potrebno_vreme
        }
        # Print the obtained values
        print(f'Ime kontrolnog: {ime_kontrolnog}')
        print(f'Start Date: {start_date}')
        print(f'End Date: {end_date}')
        print(f'Oblasti: {oblasti}')
        print(f'Tezine: {tezine}')
        print(f'Kolicine: {kolicine}')
        print(f'potrebno_vreme: {potrebno_vreme}')
        mongo.schoolDB.kontrolni.insert_one(data)

        return render_template('registration_successful.html',text=f'Uspesno ste sastavili zadatke za {ime_kontrolnog}')

@app.route('/izaberi_termin_kontrolnog', methods=['POST', 'GET'])
def izaberi_termin_kontrolnog():
    if request.method=='GET':
        # Aggregation pipeline to get the ime_kontrolnog field
        pipeline = [
            {
                "$project": {
                    "_id": 0,  # Exclude the _id field from the output
                    "ime_kontrolnog": "$ime_kontrolnog",
                }
            }
        ]

        # Execute the aggregation pipeline
        result = list(mongo.schoolDB.rezultati.aggregate(pipeline))
        termini = []
        # Print the result
        for item in result:
            termini.append(item["ime_kontrolnog"])
        return render_template('izaberi_termin_kontrolnog.html', termini=termini)
    if request.method == 'POST':
        termin = request.form.get('termin_name')
        print(termin)
        rezultati = mongo.schoolDB.rezultati.find_one({'ime_kontrolnog': termin})['rezultati']
        print(rezultati)
        table_content = render_template('rezultati_kontrolnog.html', termin=termin, results = rezultati)
        return render_template('rezultati_kontrolnog.html', termin=termin, results = rezultati,table_content=table_content)

@app.route('/kontrolni_rezultati_izbor')
def kontrolni_rezultati_izbor():
    return render_template('kontrolni_rezultati_izbor.html')

@app.route('/send_email', methods=['POST'])
def send_email():
    # Retrieve the table content from the form submission
    table_content = request.form.get('table_content')
    ime_termina = request.form.get('ime_termina')
    body = MIMEText(table_content, 'html')
    msg = Message(f"Rezultati testa za termin {ime_termina}", sender='noreply@demo.com', recipients=['trifkotrifkic@gmail.com'])
    msg.html = body.get_payload(decode=True).decode(body.get_content_charset())

    try:
        mail.send(msg)
        print('Poslata poruka')
        return render_template('registration_successful.html',text='Uspesno ste poslali rezultate. Proverite smoj mail')

    except Exception as e:
        print(f"Error sending email: {e}")
        return render_template('registration_failed.html', text='Neuspesno slanje rezultata na mail.')


@app.route('/login_ucenik')
def login_ucenik():
    lista = []
    for item in mongo.schoolDB.kontrolni.find():
        lista.append(item["ime_kontrolnog"])

    return render_template('login_ucenik.html', lista_kontrolnih=lista)

questions = []
ukupnoVreme = 0
@app.route('/zapocni_kontrolni', methods=['POST'])
def zapocni_kontrolni():
    ime_ucenika = request.form.get('imeUcenika')
    prezime_ucenika = request.form.get('prezimeUcenika')
    izabrani_kontrolni = request.form.get('oblast_name')
    kontrolni = mongo.schoolDB.kontrolni.find_one({'ime_kontrolnog': izabrani_kontrolni})
    start_date = datetime.strptime(kontrolni['start_date'], "%Y-%m-%dT%H:%M")
    end_date = datetime.strptime(kontrolni['end_date'], "%Y-%m-%dT%H:%M")
    current_time = datetime.now()
    start_date_readable = start_date.strftime("%Y-%m-%d %H:%M:%S")
    end_date_readable = end_date.strftime("%Y-%m-%d %H:%M:%S")

    if start_date <= current_time <= end_date:
        # ... (rest of your code)
        pomoci = ['Pomoc 1 vam je ...', 'Pomoc 2 vam je ...']
        # Placeholder questions
        ukunoPitanja = 0
        for kolicina in kontrolni['kolicina']:
            ukunoPitanja+=int(kolicina)
        global questions
        all_questions = [
            {'text': 'Skratiti dati razlomak...', 'id': 1, 'options': [1, 2, 3], 'correct_answer': 1,
             'pomoci': list(enumerate(pomoci)), 'resenje': 'Ovo je resenje od 1. pitanje'},
            {'text': 'Skratiti dati razlomak...', 'id': 2, 'options': [4, 5, 6], 'correct_answer': 5,
             'pomoci': list(enumerate(pomoci)), 'resenje': 'Ovo je resenje od 2. pitanje'},
            {'text': 'Skratiti dati razlomak...', 'id': 3, 'options': [4, 5, 6], 'correct_answer': 5,
             'pomoci': list(enumerate(pomoci)), 'resenje': 'Ovo je resenje od 3. pitanje'},
            {'text': 'Skratiti dati razlomak...', 'id': 4, 'options': [4, 5, 6], 'correct_answer': 5,
             'pomoci': list(enumerate(pomoci)), 'resenje': 'Ovo je resenje od 4. pitanje'},
            {'text': 'Skratiti dati razlomak...', 'id': 5, 'options': [4, 5, 6], 'correct_answer': 5,
             'pomoci': list(enumerate(pomoci)), 'resenje': 'Ovo je resenje od 5. pitanje'},
            {'text': 'Skratiti dati razlomak...', 'id': 6, 'options': [4, 5, 6], 'correct_answer': 5,
             'pomoci': list(enumerate(pomoci)), 'resenje': 'Ovo je resenje od 6. pitanje'},
            {'text': 'Skratiti dati razlomak...', 'id': 7, 'options': [4, 5, 6], 'correct_answer': 5,
             'pomoci': list(enumerate(pomoci)), 'resenje': 'Ovo je resenje od 7. pitanje'},
            {'text': 'Skratiti dati razlomak...', 'id': 8, 'options': [4, 5, 6], 'correct_answer': 5,
             'pomoci': list(enumerate(pomoci)), 'resenje': 'Ovo je resenje od 8. pitanje'},
            {'text': 'Skratiti dati razlomak...', 'id': 9, 'options': [4, 5, 6], 'correct_answer': 5,
             'pomoci': list(enumerate(pomoci)), 'resenje': 'Ovo je resenje od 9. pitanje'},
            {'text': 'Skratiti dati razlomak...', 'id': 10, 'options': [4, 5, 6], 'correct_answer': 5,
             'pomoci': list(enumerate(pomoci)), 'resenje': 'Ovo je resenje od 10. pitanje'}
        ]
        questions = random.sample(all_questions, ukunoPitanja)
        count = 1
        for q in questions:
            q['redni_broj'] = f"{count}. pitanje"
            count += 1
            random.shuffle(q['options'])
        return render_template('test.html', questions=questions, vreme = kontrolni['potrebno_vreme'], ime_kontrolnog = kontrolni['ime_kontrolnog'],ime_ucenika=ime_ucenika,prezime_ucenika=prezime_ucenika)
    else:
        return render_template('registration_failed.html', text=f'Izabrani kontrolni nije trenutno aktuelan. Aktuelan je od {start_date_readable} do {end_date_readable}')



@app.route('/resenje/<questionId>')
def prikazi_resenje(questionId):
    global questions
    resenje = ''
    for q in questions:
        if str(q['id']) == questionId:
            resenje = q['resenje']
            break

    return render_template('resenje.html', resenje=resenje)

@app.route('/record_help/<questionId>', methods=['POST'])
def record_click(questionId):
    global questions
    data = request.get_json()
    for q in questions:
        if str(q['id']) == questionId:
            q['nivoPomoci'] = int(data['nivoPomoci'])
            print('Setovanja je pomoc za pitanje ' + questionId + ' na nivo ' + str(data['nivoPomoci']))
            break

    return 'recorded'

@app.route('/record_time', methods=['POST'])
def record_time():
    global ukupnoVreme
    data = request.get_json()
    ukupnoVreme = data['ukupnoVreme']

    return 'recorded'

@app.route('/rezultat', methods=['POST'])
def rezultat():
    global questions
    global ukupnoVreme
    points = 0
    total_points = 0
    print("EEEEEE")
    ime_ucenika = request.form.get('ime_ucenika')
    prezime_ucenika = request.form.get('prezime_ucenika')
    ime_kontrolnog = request.form.get('ime_kontrolnog')
    for question in questions:
        question['tacan_netacan'] = ''
        question['points'] = 0
        selected_option = request.form.get(f'question_{question["id"]}')
        print(selected_option)
        print(question['correct_answer'])
        if question.get('nivoPomoci'):
            print('2')
            print(question['nivoPomoci'])
            if question['nivoPomoci'] == 1:
                question['points'] = 7.5
                question['nivoPomociTabela'] = 'Koristili ste jednu pomoc (-2.5 bodova)'
            elif question['nivoPomoci'] == 2:
                question['points'] = 5
                question['nivoPomociTabela'] = 'Koristili ste dve pomoc (-5 bodova)'
            elif question['nivoPomoci'] == 10:
                question['nivoPomociTabela'] = 'Prikazan rezultat (-10 bodova)'
                question['points'] = 0
        else:
            print('3')
            question['nivoPomociTabela'] = 'Pomoć nije korištena. '
            question['points'] = 10
        if selected_option == str(question['correct_answer']):
            question['tacan_netacan'] = 'Tacan odgovor'
            print('1')

        else:
            question['points'] = 0
            question['tacan_netacan'] = 'Netacan odgovor'
        points += question['points']
        total_points += 10

    minutes, seconds = divmod(ukupnoVreme, 60)
    ukupnoVremeString = f'{int(minutes):02d}:{int(seconds):02d}'
    # Pass the relevant data to the result.html template
    table_content = render_template('result.html', points=points, total_points=total_points, questions=questions,ukupnoVremeString=ukupnoVremeString, ime_ucenika=ime_ucenika,prezime_ucenika=prezime_ucenika)
    body = MIMEText(table_content, 'html')
    msg = Message(f"{ime_ucenika} {prezime_ucenika}. Rezultati testa za termin {ime_kontrolnog}", sender='noreply@demo.com',
                  recipients=['trifkotrifkic@gmail.com'])
    msg.html = body.get_payload(decode=True).decode(body.get_content_charset())

    try:
        mail.send(msg)
        print('Poslata poruka')

    except Exception as e:
        print(f"Error sending email: {e}")

    existing_doc = mongo.schoolDB.rezultati.find_one({'ime_kontrolnog': ime_kontrolnog})
    new_result = {f'{ime_ucenika} {prezime_ucenika}': '6'}
    if existing_doc:
        # If the document exists, update the 'rezultati' array
        mongo.schoolDB.rezultati.update_one(
            {'ime_kontrolnog': ime_kontrolnog},
            {'$push': {'rezultati': new_result}}
        )
    else:
        # If the document doesn't exist, create a new one
        new_doc = {'ime_kontrolnog': ime_kontrolnog, 'rezultati': [new_result]}
        mongo.schoolDB.rezultati.insert_one(new_doc)
    return render_template('result.html', points=points, total_points=total_points, questions=questions,ukupnoVremeString=ukupnoVremeString, ime_ucenika=ime_ucenika,prezime_ucenika=prezime_ucenika)


if __name__ == '__main__':
    app.run(debug=True)
